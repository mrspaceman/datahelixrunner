package org.fxmisc.richtext.api;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

public class FxmlController {
    @FXML void testWithMouseEvent( MouseEvent ME ) {
        // We're just checking that a property can be set in FXML
    }

    @FXML void testWithOutMouseEvent() {
        // We're just checking that a property can be set in FXML
    }
}
