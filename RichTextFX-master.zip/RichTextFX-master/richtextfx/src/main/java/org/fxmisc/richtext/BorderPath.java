package org.fxmisc.richtext;

import javafx.scene.shape.Path;

/**
 * A path which describes a border in the Scene graph.
 */
public class BorderPath extends Path {
}
