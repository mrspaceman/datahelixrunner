package org.fxmisc.richtext;

import javafx.scene.shape.Path;

/**
 * A path which describes an underline in the Scene graph.
 */
public class UnderlinePath extends Path {
}
