/**
 * RichTextFX utilities package.
 */
package org.fxmisc.richtext.util;