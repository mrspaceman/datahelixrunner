/**
 * Contains events useful in an area and their support classes
 */
package org.fxmisc.richtext.event;